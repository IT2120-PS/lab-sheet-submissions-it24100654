setwd("/Users/it24100654/Desktop")

branch_data <- read.table("Exercise.txt", header=TRUE,sep =",")


boxplot(branch_data$Sales_X1,
        main = "Boxplots for Sales",
        ylab ="Sales",
        col  ="yellow",
        horizontal = FALSE)

cat("Five-number summary for Advartising:\n")
print(fivenum(branch_data$Advertising_X2))

cat("IQR for Advertising:\n")
print(IQR(branch_data$Advertising_X2))

find_outliyers <- function(x){
  Q1<-quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR_val <- Q3-Q1
  lower_bound <- Q1 - 1.5 * IQR_val
  upper_bound <- Q3 - 1.5 * IQR_val
  x[x < lower_bound | x > upper_bound]
}

outliers_years <- find_outliers(branch_data$Years_X3)


cat("Outliers in Years(Years_X3):\n")
print(outliers_years)

